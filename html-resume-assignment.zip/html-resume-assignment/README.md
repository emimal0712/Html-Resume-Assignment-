# Html Resume assignment 

A Pen created on CodePen.

Original URL: [https://codepen.io/emimal0712/pen/xbOWwGp](https://codepen.io/emimal0712/pen/xbOWwGp).

